module.exports = {
  baseUrl: './',
  devServer: {
    disableHostCheck: true // Reference: https://github.com/vuejs-templates/webpack/issues/1205
  }
}
